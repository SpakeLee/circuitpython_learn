# SPDX-FileCopyrightText: 2017 Michael McWethy for Adafruit Industries
#
# SPDX-License-Identifier: MIT

"""Auto imports for Adafruit_CircuitPython_RGB_Display"""
from adafruit_rgb_display.rgb import color565
