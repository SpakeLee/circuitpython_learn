# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
#
# SPDX-License-Identifier: MIT

"""This file is included to prevent pylint
failing with the following error: no-name-in-module.
note: revisit/remove this file when this pylint error has been resolved.
"""
