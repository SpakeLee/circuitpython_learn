secrets = {
    'ssid' : '',
    'password' : '',
    'hostname': 'tallyesp01'
    }
