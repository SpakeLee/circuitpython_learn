# tally_circuitpy

Use CircuitPython to control your LEDs over HTTP

## Requirements

Requires [ampule.py](https://github.com/deckerego/ampule) installed into
the base directory.
